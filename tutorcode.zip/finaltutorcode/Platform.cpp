#include "Platform.hpp"
#include "Exceptions.hpp"
#include <iostream>
#include <stdexcept>
#include <algorithm>
using namespace std;

Platform::Platform() : nextSessionId(1) {}

int Platform::getWaitlistIndex(const string& key) {
    for (int i = 0; i < (int)waitlistKeys.size(); i++) {
        if (waitlistKeys[i] == key) return i;
    }
    waitlistKeys.push_back(key);
    waitlists.push_back(Waitlist());
    return (int)waitlists.size() - 1;
}
Tutor* Platform::findTutorById(int tutorId) {
    return linearSearch(tutors, [tutorId](const Tutor& t){
        return t.getUserId() == tutorId;
    });
}

Student* Platform::findStudentByName(const string& name) {
    return linearSearch(students, [&name](const Student& s){
        return s.getName() == name;
    });
}

Session* Platform::findSessionById(int sessionId) {
    return linearSearch(sessions, [sessionId](const Session& s){
        return s.getSessionId() == sessionId;
    });
}

// ─── Registration ─────────────────────────────────────────────────────────────
void Platform::addTutor(const Tutor& t) {
    tutors.push_back(t);
    cout << "  Tutor \"" << t.getName() << "\" (ID " << t.getUserId() << ") added.\n";
}
void Platform::addStudent(const Student& s) {
    students.push_back(s);
    cout << "  Student \"" << s.getName() << "\" added.\n";
}

// ─── Display — template + function pointer ────────────────────────────────────
static void displayTutor(Tutor& t)     { t.viewProfile(); }
static void displayStudent(Student& s) { s.viewProfile(); }
static void displaySession(Session& s) { s.displaySession(); }

void Platform::showAllTutors() {
    if (tutors.empty()) { cout << "  No tutors registered.\n"; return; }
    cout << "\n  ============ ALL TUTORS ============\n";
    displayAll(tutors, displayTutor);
}
void Platform::showAllStudents() {
    if (students.empty()) { cout << "  No students registered.\n"; return; }
    cout << "\n  ============ ALL STUDENTS ============\n";
    displayAll(students, displayStudent);
}
void Platform::showAllSessions() {
    if (sessions.empty()) { cout << "  No sessions recorded.\n"; return; }
    cout << "\n  ============ ALL SESSIONS ============\n";
    displayAll(sessions, displaySession);
}

// ─── Search ───────────────────────────────────────────────────────────────────
void Platform::viewTutorById(int tutorId) {
    Tutor* t = findTutorById(tutorId);
    if (!t) { cout << "  No tutor found with ID " << tutorId << ".\n"; return; }
    t->viewProfile();
}

void Platform::searchTutors(const string& name, const string& subject) {
    bool byName    = !name.empty();
    bool bySubject = !subject.empty();

    cout << "\n  === Search Results";
    if (byName)    cout << "  Name: \"" << name << "\"";
    if (bySubject) cout << "  Subject: \"" << subject << "\"";
    cout << " ===\n";

    auto matches = filterVec(tutors, [&](const Tutor& t) {
        bool nameOk    = !byName    || t.getName() == name;
        bool subjectOk = !bySubject || t.teachesSubject(subject);
        return nameOk && subjectOk;
    });

    if (matches.empty()) {
        cout << "  No tutors found matching your search.\n";
        return;
    }
    for (auto* t : matches) t->viewProfile();
    cout << "  " << matches.size() << " tutor(s) found.\n";
}

// ─── Recommend ───────────────────────────────────────────────────────────
void Platform::recommendTutors(const string& subject) {
    cout << "\n  === Recommended Tutors for \"" << subject << "\" ===\n";
    auto recs = recommender.recommendTutors(tutors, subject);
    if (recs.empty()) {
        cout << "  No tutors found who teach \"" << subject << "\".\n";
        return;
    }
    for (int i = 0; i < (int)recs.size(); i++) {
        float score = recommender.calculateScore(*recs[i], subject);
        cout << "\n  Rank #" << i + 1 << " (Score: " << score << ")";
        recs[i]->viewProfile();
    }
}

// ─── bookSession ──────────────────────────────────────────────────────────────
void Platform::bookSession(int tutorId, const string& studentName,
                            const string& subject, int slotId) {
    try {
        Tutor*   tutor   = findTutorById(tutorId);
        if (!tutor)   throw TutorNotFoundException(tutorId);

        Student* student = findStudentByName(studentName);
        if (!student) throw StudentNotFoundException(studentName);

        TimeSlot* slot = tutor->findSlot(slotId);
        if (!slot)    throw SlotNotFoundException(slotId);

        string waitlistKey = to_string(tutorId) + "_" + to_string(slotId);
        int wIdx = getWaitlistIndex(waitlistKey); // cache index once

        if (slot->getIsBooked()) {
            cout << "  Slot already booked. Adding \""
                 << studentName << "\" to priority waitlist...\n";
            waitlists[wIdx].addStudent(studentName, student->reliabilityScore());
            return;
        }

        slot->bookSlot();
        string slotInfo = slot->getDate() + " " + slot->getTime();
        Session newSession(nextSessionId++, tutor->getName(),
                           studentName, subject, slotInfo, slotId);
        sessions.push_back(newSession);
        student->recordBooking(newSession);

        cout << "  Session booked successfully!\n";
        newSession.displaySession();

    } catch (TutorNotFoundException& e)   { cout << "  [ERROR] " << e.what() << "\n"; }
    catch (StudentNotFoundException& e) { cout << "  [ERROR] " << e.what() << "\n"; }
    catch (SlotNotFoundException& e)    { cout << "  [ERROR] " << e.what() << "\n"; }
}

// ─── cancelSession ────────────────────────────────────────────────────────────
void Platform::cancelSession(int sessionId,int studentId) {
    try {
        Session* sess = findSessionById(sessionId);
        if (!sess) throw SessionNotFoundException(sessionId);
        if (sess->getStatus() == "Cancelled") throw AlreadyCancelledException(sessionId);
        Student* requestingStudent = linearSearch(students, [studentId](const Student& s){
            return s.getUserId() == studentId;
        });
        
        if (!requestingStudent) {
            throw runtime_error("Student ID " + to_string(studentId) + " not found.");
        }
        if (sess->getStudentName() != requestingStudent->getName()) {
            throw runtime_error("Authorization failed: This session belongs to a different student.");
        }

        string tutorName    = sess->getTutorName();
        string studentName  = sess->getStudentName();
        string subject      = sess->getSubject();
        string slotInfo     = sess->getSlotInfo();
        int    bookedSlotId = sess->getSlotId(); // BUG FIX: match by ID

        sess->cancelSession();
      
        Tutor* tutor = linearSearch(tutors, [&tutorName](const Tutor& t){
            return t.getName() == tutorName;
        });
        if (!tutor) throw runtime_error("Tutor not found while cancelling.");

        Student* student = findStudentByName(studentName);
        if (student) student->recordCancellation();

        auto& slots = tutor->getAvailableSlots();
        for (int i = 0; i < (int)slots.size(); i++) {
            if (slots[i].getSlotId() == bookedSlotId && slots[i].getIsBooked()) {
                slots[i].freeSlot();

                int    tId  = tutor->getUserId();
                string key  = to_string(tId) + "_" + to_string(bookedSlotId);
                int    wIdx = getWaitlistIndex(key); // cache index once

                if (!waitlists[wIdx].isEmpty()) {
                    string nextStudent = waitlists[wIdx].getNextStudent();
                    cout << "  [Waitlist] Auto-assigning to: \"" << nextStudent << "\"\n";
                    slots[i].bookSlot();
                    Session newSession(nextSessionId++, tutorName,
                                       nextStudent, subject, slotInfo, bookedSlotId);
                    sessions.push_back(newSession);
                    Student* ns = findStudentByName(nextStudent);
                    if (ns) ns->recordBooking(newSession);
                    cout << "  New session created:\n";
                    newSession.displaySession();
                }
                break;
            }
        }

    } catch (SessionNotFoundException& e)   { cout << "  [ERROR] " << e.what() << "\n"; }
    catch (AlreadyCancelledException& e)  { cout << "  [ERROR] " << e.what() << "\n"; }
    catch (runtime_error& e)              { cout << "  [ERROR] " << e.what() << "\n"; }
}

// ─── rateSession ─────────────────────────────────────────────────────────────
void Platform::rateSession(int sessionId, const string& studentName,
                            float rating, const string& review) {
    try {
        Session* sess = findSessionById(sessionId);
        if (!sess) throw SessionNotFoundException(sessionId);

        if (sess->getStatus() == "Cancelled")
            throw RatingException("Cannot rate a cancelled session.");

        if (sess->getStudentName() != studentName)
            throw RatingException("Only the attending student can rate this session.");

        if (sess->getIsRated())
            throw RatingException("Session " + to_string(sessionId) +
                                  " has already been rated.");

        if (rating < 0.0f || rating > 5.0f)
            throw RatingException("Rating must be between 0.0 and 5.0.");

        sess->completeWithRating(rating, review);

        Tutor* tutor = linearSearch(tutors, [&sess](const Tutor& t){
            return t.getName() == sess->getTutorName();
        });
        if (tutor) tutor->addRating(rating);

        cout << "  Thank you, " << studentName << "! Rating submitted.\n";
        sess->displaySession();

    } catch (SessionNotFoundException& e) { cout << "  [ERROR] " << e.what() << "\n"; }
    catch (RatingException& e)           { cout << "  [ERROR] " << e.what() << "\n"; }
}

// ─── Waitlist & History ───────────────────────────────────────────────────────
void Platform::showWaitlist(int tutorId, int slotId) {
    string key = to_string(tutorId) + "_" + to_string(slotId);
    cout << "\n  Waitlist for Tutor ID " << tutorId << ", Slot " << slotId << ":\n";
    int idx = getWaitlistIndex(key);
    waitlists[idx].displayWaitlist();
}

void Platform::viewStudentHistory(const string& studentName) {
    Student* s = findStudentByName(studentName);
    if (!s) { cout << "  Student not found.\n"; return; }

    cout << "\n  === Session History for " << studentName << " ===\n";
    bool found = false;
    for (auto& sess : sessions) {
        if (sess.getStudentName() == studentName) {
            sess.displaySession();
            found = true;
        }
    }
    if (!found) cout << "  No sessions found for this student.\n";
    cout << "  Booked: " << s->getTotalBooked()
         << "  Cancelled: " << s->getCancelledCount()
         << "  Reliability: " << s->reliabilityScore() << "\n";
}

// ─── Interactive menu ─────────────────────────────────────────────────────────
void Platform::menu() {
    int choice;
    do {
        cout << "\n+======================================+\n";
        cout << "|   TUTOR AVAILABILITY PLATFORM MENU   |\n";
        cout << "+======================================+\n";
        cout << "|  1. Add Tutor                        |\n";
        cout << "|  2. Add Student                      |\n";
        cout << "|  3. Show All Tutors                  |\n";
        cout << "|  4. Show All Students                |\n";
        cout << "|  5. Search Tutors (name / subject)   |\n";
        cout << "|  6. View Tutor by ID                 |\n";
        cout << "|  7. Recommend Tutors by Subject      |\n";
        cout << "|  8. Book Session                     |\n";
        cout << "|  9. Cancel Session                   |\n";
        cout << "| 10. Show All Sessions                |\n";
        cout << "| 11. Show Waitlist                    |\n";
        cout << "| 12. View Student Session History     |\n";
        cout << "| 13. Rate a Session (students only)   |\n";
        cout << "|  0. Exit                             |\n";
        cout << "+======================================+\n";
        cout << "  Enter choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            int exp;
            string name, contact;
            cout << "  Name: ";             getline(cin, name);
            cout << "  Contact: ";          getline(cin, contact);
            cout << "  Experience (yrs): "; cin >> exp; cin.ignore();
            Tutor t(name, contact, exp);
            int ns; cout << "  # subjects: "; cin >> ns; cin.ignore();
            for (int i = 0; i < ns; i++) {
                string subj; cout << "  Subject " << i+1 << ": "; getline(cin, subj);
                t.addSubject(subj);
            }
            int nsl; cout << "  # time slots: "; cin >> nsl; cin.ignore();
            for (int i = 0; i < nsl; i++) {
                string date, time;
                cout << "  Date (YYYY-MM-DD): ";    getline(cin, date);
                cout << "  Time (e.g. 10:00 AM): "; getline(cin, time);
                t.addAvailability(TimeSlot(date, time));
            }
            addTutor(t);

        } else if (choice == 2) {
            string name, contact;
            cout << "  Name: ";    getline(cin, name);
            cout << "  Contact: "; getline(cin, contact);
            addStudent(Student(name, contact));

        } else if (choice == 3)  { showAllTutors();
        } else if (choice == 4)  { showAllStudents();
        } else if (choice == 5)  {
            string name, subj;
            cout << "  Name (leave blank to skip): ";    getline(cin, name);
            cout << "  Subject (leave blank to skip): "; getline(cin, subj);
            searchTutors(name, subj);
        } else if (choice == 6)  {
            int id; cout << "  Tutor ID: "; cin >> id; cin.ignore();
            viewTutorById(id);
        } else if (choice == 7)  {
            string subj;
            cout << "  Subject: "; getline(cin, subj);
            recommendTutors(subj);
        } else if (choice == 8)  {
            int tid, slotId; string sName, subj;
            cout << "  Tutor ID: ";     cin >> tid;    cin.ignore();
            cout << "  Student name: "; getline(cin, sName);
            cout << "  Subject: ";      getline(cin, subj);
            cout << "  Slot ID: ";      cin >> slotId; cin.ignore();
            bookSession(tid, sName, subj, slotId);
        } else if (choice == 9)  {
            int sid, stid; 
            cout << "  Session ID to cancel: "; cin >> sid; cin.ignore();
            cout << "  Your Student ID: ";      cin >> stid; cin.ignore();
            cancelSession(sid, stid);
        } else if (choice == 10) { showAllSessions();
        } else if (choice == 11) {
            int tid, slotId;
            cout << "  Tutor ID: "; cin >> tid;    cin.ignore();
            cout << "  Slot ID: ";  cin >> slotId; cin.ignore();
            showWaitlist(tid, slotId);
        } else if (choice == 12) {
            string name; cout << "  Student name: "; getline(cin, name);
            viewStudentHistory(name);
        } else if (choice == 13) {
            int sid; float r; string sName, review;
            cout << "  Session ID: ";   cin >> sid; cin.ignore();
            cout << "  Your name: ";    getline(cin, sName);
            cout << "  Rating (0-5): "; cin >> r;   cin.ignore();
            cout << "  Review: ";       getline(cin, review);
            rateSession(sid, sName, r, review);
        } else if (choice != 0) {
            cout << "  Invalid option.\n";
        }
    } while (choice != 0);
    cout << "\n  Goodbye!\n";
}
