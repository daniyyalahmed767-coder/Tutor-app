#include "Waitlist.hpp"

void Waitlist::insertSorted(const WaitlistEntry& e) {
    // Find the first position where e.score > entries[i].score — insert before it.
    int pos = (int)entries.size();
    for (int i = 0; i < (int)entries.size(); i++) {
        if (e.reliabilityScore > entries[i].reliabilityScore) {
            pos = i;
            break;
        }
    }
    entries.insert(entries.begin() + pos, e);
}

void Waitlist::addStudent(const string& studentName, float reliabilityScore) {
    insertSorted(WaitlistEntry(studentName, reliabilityScore));
    cout << "  [Waitlist] \"" << studentName
         << "\" added (reliability " << reliabilityScore << ").\n";
}

string Waitlist::getNextStudent() {
    if (entries.empty()) return "";
    string name = entries.front().studentName;
    entries.erase(entries.begin());
    return name;
}

bool Waitlist::isEmpty() const {
    return entries.empty();
}

void Waitlist::displayWaitlist() const {
    if (entries.empty()) {
        cout << "  Waitlist is empty.\n";
        return;
    }
    cout << "  Priority Waitlist (highest reliability first):\n";
    for (int i = 0; i < (int)entries.size(); i++) {
        cout << "    " << (i + 1) << ". " << entries[i].studentName
             << "  [reliability: " << entries[i].reliabilityScore << "]\n";
    }
}
