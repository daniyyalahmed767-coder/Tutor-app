#pragma once
#include <string>
#include <vector>
#include <iostream>
using namespace std;

struct WaitlistEntry {
    string studentName;
    float  reliabilityScore; // 0.0 – 1.0  

    WaitlistEntry(const string& name, float score)
        : studentName(name), reliabilityScore(score) {}
};

class Waitlist {
private:
    vector<WaitlistEntry> entries; // sorted descending by reliabilityScore

    void insertSorted(const WaitlistEntry& e);

public:
    // Add student with their current reliability score.
    void addStudent(const string& studentName, float reliabilityScore);

    // Remove and return the highest-priority student.
    // Returns "" if empty.
    string getNextStudent();

    bool isEmpty() const;

    void displayWaitlist() const;
};
