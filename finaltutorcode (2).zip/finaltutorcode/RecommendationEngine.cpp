#include "RecommendationEngine.hpp"
#include <algorithm>
using namespace std;

bool ScoreComparator::operator()(Tutor* a, Tutor* b) const {
    float scoreA = engine->calculateScore(*a, subject);
    float scoreB = engine->calculateScore(*b, subject);
    if (scoreA == scoreB) {
        return a->getExperienceYears() > b->getExperienceYears();
    }
    return scoreA > scoreB;
}

float RecommendationEngine::calculateScore(Tutor& tutor,
                                           const string& subject) const {
    if (!tutor.teachesSubject(subject)) return 0.0f;
    float score = 50.0f;
    score += tutor.getRating() * 10.0f; // 0–50 pts from student ratings
    return score;
}

vector<Tutor*> RecommendationEngine::recommendTutors(vector<Tutor>& tutors,
                                                      const string& subject) {
    vector<Tutor*> matched;
    for (int i = 0; i < (int)tutors.size(); i++) {
        if (calculateScore(tutors[i], subject) > 0.0f)
            matched.push_back(&tutors[i]);
    }
    ScoreComparator cmp(this, subject);
    std::sort(matched.begin(), matched.end(), cmp);
    return matched;
}
