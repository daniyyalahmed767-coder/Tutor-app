#include "Student.hpp"
#include <iostream>
using namespace std;

int Student::nextStudentId = 1;

Student::Student() : User(), totalBooked(0), cancelledCount(0) {}

Student::Student(const string& n, const string& contact)
    : User(nextStudentId++, n, contact), totalBooked(0), cancelledCount(0) {}

void Student::recordBooking(const Session& s) {
    sessionHistory.push_back(s);
    totalBooked++;
}

void Student::recordCancellation() {
    cancelledCount++;
}

float Student::reliabilityScore() const {
    if (totalBooked == 0) return 0.0f;
    return (float)(totalBooked - cancelledCount) / (float)totalBooked;
}

int Student::getTotalBooked()    const { return totalBooked; }
int Student::getCancelledCount() const { return cancelledCount; }

void Student::viewProfile() {
    cout << "\n  ========== STUDENT PROFILE ==========\n";
    cout << "  ID              : " << getUserId()        << "\n";
    cout << "  Name            : " << getName()          << "\n";
    cout << "  Contact         : " << getContactInfo()   << "\n";
    cout << "  Total Booked    : " << totalBooked        << "\n";
    cout << "  Cancellations   : " << cancelledCount     << "\n";
    cout << "  Reliability     : " << reliabilityScore() << " / 1.0\n";
    cout << "  Session History : " << sessionHistory.size() << " record(s)\n";
    cout << "  =====================================\n";
}

void Student::viewSessionHistory() const {
    if (sessionHistory.empty()) {
        cout << "  No session history found.\n";
        return;
    }
    cout << "\n  === Session History for " << getName() << " ===\n";
    for (int i = 0; i < (int)sessionHistory.size(); i++)
        sessionHistory[i].displaySession();
}
