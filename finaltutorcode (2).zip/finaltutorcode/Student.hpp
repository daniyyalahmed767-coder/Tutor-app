#pragma once
#include "User.hpp"
#include "Session.hpp"
#include <vector>
#include <string>
using namespace std;

// ─── Student (Derived from User) ─────────────────────────────────────────────
class Student : public User {
private:
    static int nextStudentId;   

    vector<Session> sessionHistory;
    int totalBooked;
    int cancelledCount;

public:
    Student();
    Student(const string& n, const string& contact);

    void recordBooking(const Session& s);
    void recordCancellation();

    float reliabilityScore() const;
    int   getTotalBooked()    const;
    int   getCancelledCount() const;

    void viewProfile()        override;
    void viewSessionHistory() const;
};
