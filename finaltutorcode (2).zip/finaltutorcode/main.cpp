#include "Platform.hpp"
#include "Exceptions.hpp"
#include <iostream>
#include <string>
using namespace std;

static int passed = 0, failed = 0;

void check(bool condition, const string& testName) {
    if (condition) { cout << "  [PASS] " << testName << "\n"; passed++; }
    else           { cout << "  [FAIL] " << testName << "\n"; failed++; }
}

void seedPlatform(Platform& p) {
    Tutor t1("Alice",   "alice@uni.edu",   5);
    t1.addSubject("Math"); t1.addSubject("Physics");
    t1.addAvailability(TimeSlot("2025-06-10", "10:00 AM")); // slot ID 1
    t1.addAvailability(TimeSlot("2025-06-11", "02:00 PM")); // slot ID 2
    p.addTutor(t1);

    Tutor t2("Bob",     "bob@uni.edu",     2);
    t2.addSubject("Chemistry");
    t2.addAvailability(TimeSlot("2025-06-10", "10:00 AM")); // slot ID 3
    p.addTutor(t2);

    Tutor t3("Charlie", "charlie@uni.edu", 8);
    t3.addSubject("Math");
    t3.addAvailability(TimeSlot("2025-06-10", "10:00 AM")); // slot ID 4
    t3.addAvailability(TimeSlot("2025-06-12", "11:00 AM")); // slot ID 5
    p.addTutor(t3);

    // Students: IDs assigned 1, 2, 3 automatically
    p.addStudent(Student("Zara",  "zara@s.com"));
    p.addStudent(Student("Ahmed", "ahmed@s.com"));
    p.addStudent(Student("Sara",  "sara@s.com"));
}

//Helper: find a session ID by student name and status ─────────────────────
int findSessionId(Platform& p, const string& student, const string& status = "Scheduled") {
    for (auto& s : p.getSessions())
        if (s.getStudentName() == student && s.getStatus() == status)
            return s.getSessionId();
    return -1;
}

// ─── Helper: find a slot ID by tutor name and availability ────────────────────
int findFreeSlotId(Platform& p, int tutorId) {
    for (auto& t : p.getTutors())
        if (t.getUserId() == tutorId)
            for (auto& s : t.getAvailableSlots())
                if (!s.getIsBooked()) return s.getSlotId();
    return -1;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

void tc01_autoIds() {
    cout << "\n[TC-01] Auto-assigned IDs are sequential and unique\n";
    // Fresh objects — IDs continue from where static counters left off
    Tutor  ta("TempA", "", 1);
    Tutor  tb("TempB", "", 1);
    check(tb.getUserId() == ta.getUserId() + 1, "TC-01a Tutor IDs sequential");

    Student sa("TempS1", "");
    Student sb("TempS2", "");
    check(sb.getUserId() == sa.getUserId() + 1, "TC-01b Student IDs sequential");

    TimeSlot sl1("2025-01-01", "09:00 AM");
    TimeSlot sl2("2025-01-02", "10:00 AM");
    check(sl2.getSlotId() == sl1.getSlotId() + 1, "TC-01c Slot IDs sequential");
}

void tc02_bookSession(Platform& p) {
    cout << "\n[TC-02] Book session: Tutor 1 (Alice), Zara, Math, first free slot\n";
    int slot = findFreeSlotId(p, 1);
    check(slot != -1, "TC-02a Alice has a free slot");
    p.bookSession(1, "Zara", "Math", slot);
    check(true, "TC-02b session booked");
}

void tc03_waitlist(Platform& p) {
    cout << "\n[TC-03] Book same slot -> Ahmed goes to waitlist\n";
    int sid = findSessionId(p, "Zara");
    int slot = -1;
    for (auto& s : p.getSessions())
        if (s.getSessionId() == sid) { slot = s.getSlotId(); break; }
    p.bookSession(1, "Ahmed", "Math", slot);
    check(true, "TC-03 Ahmed waitlisted");
}

void tc04_tutorNotFound(Platform& p) {
    cout << "\n[TC-04] Non-existent tutor ID 999\n";
    p.bookSession(999, "Zara", "Math", 1);
    check(true, "TC-04 TutorNotFoundException handled");
}

void tc05_studentNotFound(Platform& p) {
    cout << "\n[TC-05] Non-existent student 'Ghost'\n";
    p.bookSession(1, "Ghost", "Math", 1);
    check(true, "TC-05 StudentNotFoundException handled");
}

void tc06_slotNotFound(Platform& p) {
    cout << "\n[TC-06] Non-existent slot ID 9999\n";
    p.bookSession(1, "Sara", "Math", 9999);
    check(true, "TC-06 SlotNotFoundException handled");
}
int findStudentId(Platform& p, const string& name) {
    for (auto& s : p.getStudents()) {
        if (s.getName() == name) return s.getUserId();
    }
    return -1;
}

void tc07_cancelAndWaitlist(Platform& p) {
    cout << "\n[TC-07] Cancel Zara's session -> Ahmed auto-assigned from waitlist\n";
    int sid = findSessionId(p, "Zara");
    int stid = findStudentId(p, "Zara"); // Fetch Zara's actual ID
    
    check(sid != -1, "TC-07a Zara's session found");
    p.cancelSession(sid, stid); // Pass BOTH arguments here
    check(true, "TC-07b cancel + waitlist auto-assign executed");
}

void tc08_doubleCancel(Platform& p) {
    cout << "\n[TC-08] Cancel same session again -> error\n";
    // Zara's session (now Cancelled)
    int sid = findSessionId(p, "Zara", "Cancelled");
    int stid = findStudentId(p, "Zara"); // Fetch Zara's actual ID again
    
    p.cancelSession(sid, stid); // Pass BOTH arguments here
    check(true, "TC-08 AlreadyCancelledException handled");
}

void tc09_cancelMissing(Platform& p) {
    cout << "\n[TC-09] Cancel non-existent session 9999\n";
    // The session doesn't exist, so the code will throw the 
    // SessionNotFoundException before it even checks the student ID.
    // We can just safely pass a dummy ID like 999 here.
    p.cancelSession(9999, 999); 
    check(true, "TC-09 SessionNotFoundException handled");
}

void tc10_recommend(Platform& p) {
    cout << "\n[TC-10] Recommend tutors for Math\n";
    p.recommendTutors("Math");
    check(true, "TC-10 recommendation executed");
}

void tc11_hardGate(Platform& /*p*/) {
    cout << "\n[TC-11] Bob (Chemistry) must NOT appear in Math recommendations\n";
    Platform tmp;
    Tutor charlie("Charlie2", "", 8); charlie.addSubject("Math");
    charlie.addAvailability(TimeSlot("2025-06-10", "10:00 AM"));
    tmp.addTutor(charlie);
    Tutor bob("Bob2", "", 2); bob.addSubject("Chemistry");
    bob.addAvailability(TimeSlot("2025-06-10", "10:00 AM"));
    tmp.addTutor(bob);

    RecommendationEngine eng;
    auto recs = eng.recommendTutors(tmp.getTutors(), "Math");
    bool bobIn = false;
    for (auto* t : recs) if (t->getName() == "Bob2") bobIn = true;
    check(!bobIn,          "TC-11a Bob not in Math results (hard gate)");
    check(recs.size() >= 1,"TC-11b Charlie in Math results");
}

void tc12_searchBySubject(Platform& p) {
    cout << "\n[TC-12] Search: subject='Math', name blank\n";
    p.searchTutors("", "Math");
    check(true, "TC-12 subject search executed");
}

void tc13_searchByName(Platform& p) {
    cout << "\n[TC-13] Search: name='Alice', subject blank\n";
    p.searchTutors("Alice", "");
    check(true, "TC-13 name search executed");
}

void tc14_searchBoth(Platform& p) {
    cout << "\n[TC-14] Search: name='Alice', subject='Physics'\n";
    p.searchTutors("Alice", "Physics");
    check(true, "TC-14 name+subject search executed");
}

void tc15_searchMissing(Platform& p) {
    cout << "\n[TC-15] Search: subject='Basket Weaving' -> no results\n";
    p.searchTutors("", "Basket Weaving");
    check(true, "TC-15 no crash on missing subject");
}

void tc16_viewTutorById(Platform& p) {
    cout << "\n[TC-16] View tutor by ID 2 (Bob)\n";
    p.viewTutorById(2);
    check(true, "TC-16 viewTutorById executed");
}

void tc17_viewTutorByBadId(Platform& p) {
    cout << "\n[TC-17] View tutor by non-existent ID 888\n";
    p.viewTutorById(888);
    check(true, "TC-17 no crash on bad ID");
}

void tc18_duplicateSlot() {
    cout << "\n[TC-18] Duplicate slot detection\n";
    // With auto IDs, duplicates can only come from copying a TimeSlot object
    // and calling addAvailability with the same underlying ID.
    Tutor t("DupTest", "", 1);
    TimeSlot sl("2025-01-01", "08:00 AM");
    t.addAvailability(sl);
    bool threw = false;
    try { t.addAvailability(sl); }   // same object -> same slotId
    catch (DuplicateSlotException&) { threw = true; }
    check(threw, "TC-18 DuplicateSlotException thrown on same slot object");
}

void tc19_reliability() {
    cout << "\n[TC-19] Reliability score calculation\n";
    Student s("RelTest", "");
    check(s.reliabilityScore() == 0.0f, "TC-19a 0 booked -> 0.0");
    Session dummy(1, "T", "RelTest", "Math", "2025-01-01 10:00", 1);
    s.recordBooking(dummy); s.recordBooking(dummy); s.recordBooking(dummy);
    check(s.reliabilityScore() == 1.0f, "TC-19b 3 booked, 0 cancelled -> 1.0");
    s.recordCancellation();
    check(s.reliabilityScore() > 0.66f && s.reliabilityScore() < 0.67f,
          "TC-19c 3 booked, 1 cancelled -> ~0.667");
    s.recordCancellation(); s.recordCancellation();
    check(s.reliabilityScore() == 0.0f, "TC-19d 3 booked, 3 cancelled -> 0.0");
}

void tc20_priorityWaitlist() {
    cout << "\n[TC-20] Priority waitlist orders by reliability score\n";
    Waitlist wl;
    wl.addStudent("Low",  0.2f);
    wl.addStudent("High", 0.9f);
    wl.addStudent("Mid",  0.6f);
    check(wl.getNextStudent() == "High", "TC-20a High served first");
    check(wl.getNextStudent() == "Mid",  "TC-20b Mid served second");
}

void tc21_bookSara(Platform& p) {
    cout << "\n[TC-21] Book Sara into Charlie (ID 3), first free slot\n";
    int slot = findFreeSlotId(p, 3);
    check(slot != -1, "TC-21a Charlie has a free slot");
    p.bookSession(3, "Sara", "Math", slot);
    check(true, "TC-21b Sara booked");
}

void tc22_showAllSessions(Platform& p) {
    cout << "\n[TC-22] Show all sessions\n";
    p.showAllSessions();
    check(true, "TC-22 showAllSessions executed");
}

void tc23_studentHistory(Platform& p) {
    cout << "\n[TC-23] View session history for Zara (should show Cancelled)\n";
    p.viewStudentHistory("Zara");
    check(true, "TC-23 history displayed with live status");
}

void tc24_rateSession(Platform& p) {
    cout << "\n[TC-24] Sara rates her session with Charlie\n";
    int sid = findSessionId(p, "Sara");
    check(sid != -1, "TC-24a Sara's session found");
    if (sid != -1) {
        p.rateSession(sid, "Sara", 4.8f, "Very clear explanations!");
        Tutor* charlie = nullptr;
        for (auto& t : p.getTutors()) if (t.getUserId() == 3) charlie = &t;
        check(charlie && charlie->getRatingCount() == 1, "TC-24b rating count 1");
        check(charlie && charlie->getRating() == 4.8f,   "TC-24c average = 4.8");
    }
}

void tc25_doubleRating(Platform& p) {
    cout << "\n[TC-25] Sara rates same session again -> blocked\n";
    int sid = findSessionId(p, "Sara", "Completed");
    if (sid != -1) p.rateSession(sid, "Sara", 2.0f, "Changed my mind");
    Tutor* charlie = nullptr;
    for (auto& t : p.getTutors()) if (t.getUserId() == 3) charlie = &t;
    check(charlie && charlie->getRatingCount() == 1, "TC-25 double-rating blocked");
}

void tc26_wrongStudentRating(Platform& p) {
    cout << "\n[TC-26] Ahmed tries to rate Sara's session -> blocked\n";
    int sid = findSessionId(p, "Sara", "Completed");
    if (sid != -1) p.rateSession(sid, "Ahmed", 1.0f, "I was not there");
    check(true, "TC-26 wrong-student rating blocked");
}

void tc27_rateCancelledSession(Platform& p) {
    cout << "\n[TC-27] Rate Zara's cancelled session -> blocked\n";
    int sid = findSessionId(p, "Zara", "Cancelled");
    if (sid != -1) p.rateSession(sid, "Zara", 5.0f, "Great");
    check(true, "TC-27 rating cancelled session blocked");
}

void tc28_outOfRangeRating(Platform& p) {
    cout << "\n[TC-28] Rate Ahmed's session with rating 9.0 (out of range)\n";
    int sid = findSessionId(p, "Ahmed");
    check(sid != -1, "TC-28a Ahmed's session found");
    if (sid != -1) {
        p.rateSession(sid, "Ahmed", 9.0f, "Off the charts");
        check(true, "TC-28b out-of-range rating blocked");
    }
}

void tc29_tutorNoSelfRating() {
    cout << "\n[TC-29] Tutor starts with no rating; addRating() builds average\n";
    Tutor t("RatingTest", "", 1);
    check(t.getRating() == 0.0f,   "TC-29a starts at 0.0");
    check(t.getRatingCount() == 0, "TC-29b count is 0");
    t.addRating(3.0f); t.addRating(5.0f);
    check(t.getRating() == 4.0f,   "TC-29c (3+5)/2 = 4.0");
}

int main() {
    cout << "+================================================+\n";
    cout << "|   TUTOR AVAILABILITY PLATFORM - TEST SUITE    |\n";
    cout << "+================================================+\n";

    Platform p;
    seedPlatform(p);

    tc01_autoIds();
    tc02_bookSession(p);
    tc03_waitlist(p);
    tc04_tutorNotFound(p);
    tc05_studentNotFound(p);
    tc06_slotNotFound(p);
    tc07_cancelAndWaitlist(p);
    tc08_doubleCancel(p);
    tc09_cancelMissing(p);
    tc10_recommend(p);
    tc11_hardGate(p);
    tc12_searchBySubject(p);
    tc13_searchByName(p);
    tc14_searchBoth(p);
    tc15_searchMissing(p);
    tc16_viewTutorById(p);
    tc17_viewTutorByBadId(p);
    tc18_duplicateSlot();
    tc19_reliability();
    tc20_priorityWaitlist();
    tc21_bookSara(p);
    tc22_showAllSessions(p);
    tc23_studentHistory(p);
    tc24_rateSession(p);
    tc25_doubleRating(p);
    tc26_wrongStudentRating(p);
    tc27_rateCancelledSession(p);
    tc28_outOfRangeRating(p);
    tc29_tutorNoSelfRating();

    cout << "\n+================================================+\n";
    cout << "|  RESULTS: " << passed << " passed, " << failed << " failed";
    int pad = 38 - (int)to_string(passed).size() - (int)to_string(failed).size();
    for (int i = 0; i < pad; i++) cout << ' ';
    cout << "|\n";
    cout << "+================================================+\n";
    return 0;
}
