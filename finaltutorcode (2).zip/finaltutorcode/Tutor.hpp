#pragma once
#include "User.hpp"
#include "TimeSlot.hpp"
#include <vector>
#include <string>
using namespace std;

class Tutor : public User {
private:
    static int nextTutorId;     

    vector<string>   subjects;
    int              experienceYears;
    float            ratingSum;
    int              ratingCount;
    vector<TimeSlot> availableSlots;

public:
    Tutor();
    Tutor(const string& n, const string& contact, int exp);

    float getRating()      const;
    int   getRatingCount() const;
    int   getExperienceYears() const;

    void addRating(float r);    
    void addSubject(const string& subject);
    void addAvailability(const TimeSlot& slot); 

    bool      teachesSubject(const string& subj) const;
    bool      isAvailable(int slotId)            const;
    TimeSlot* findSlot(int slotId);

    vector<TimeSlot>&     getAvailableSlots();
    const vector<string>& getSubjects() const;

    void viewProfile() override;
};
