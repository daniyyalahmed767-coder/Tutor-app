#pragma once
#include "Tutor.hpp"
#include <vector>
#include <string>
using namespace std;

class RecommendationEngine;

class ScoreComparator {
private:
    RecommendationEngine* engine;
    string subject;
public:
    ScoreComparator(RecommendationEngine* e, const string& s)
        : engine(e), subject(s) {}
    bool operator()(Tutor* a, Tutor* b) const;
};

class RecommendationEngine {
public:
    // Score based on subject match + student ratings only.
    float calculateScore(Tutor& tutor, const string& subject) const;
    vector<Tutor*> recommendTutors(vector<Tutor>& tutors, const string& subject);
};
