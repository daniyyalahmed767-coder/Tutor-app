#include "Session.hpp"

Session::Session()
    : sessionId(0), tutorName(""), studentName(""), subject(""),
      slotInfo(""), slotId(0), status("Scheduled"),
      isRated(false), studentRating(0.0f), studentReview("") {}

Session::Session(int id, const string& tName, const string& sName,
                 const string& subj, const string& slot, int sId)
    : sessionId(id), tutorName(tName), studentName(sName),
      subject(subj), slotInfo(slot), slotId(sId), status("Scheduled"),
      isRated(false), studentRating(0.0f), studentReview("") {}

int    Session::getSessionId()     const { return sessionId; }
string Session::getTutorName()     const { return tutorName; }
string Session::getStudentName()   const { return studentName; }
string Session::getSubject()       const { return subject; }
string Session::getSlotInfo()      const { return slotInfo; }
int    Session::getSlotId()        const { return slotId; }
string Session::getStatus()        const { return status; }
bool   Session::getIsRated()       const { return isRated; }
float  Session::getStudentRating() const { return studentRating; }
string Session::getStudentReview() const { return studentReview; }

void Session::setStatus(const string& s)      { status = s; }
void Session::setStudentName(const string& s) { studentName = s; }

void Session::cancelSession() {
    status = "Cancelled";
    cout << "  Session ID " << sessionId << " has been cancelled.\n";
}

void Session::completeWithRating(float rating, const string& review) {
    isRated       = true;
    studentRating = rating;
    studentReview = review;
    status        = "Completed";
}

void Session::displaySession() const {
    cout << "  +-----------------------------------------+\n";
    cout << "  Session ID : " << sessionId   << "\n";
    cout << "  Tutor      : " << tutorName   << "\n";
    cout << "  Student    : " << studentName << "\n";
    cout << "  Subject    : " << subject     << "\n";
    cout << "  Slot       : " << slotInfo    << " (Slot ID " << slotId << ")\n";
    cout << "  Status     : " << status      << "\n";
    if (isRated) {
        cout << "  Rating     : " << studentRating << " / 5.0\n";
        if (!studentReview.empty())
            cout << "  Review     : " << studentReview << "\n";
    }
    cout << "  +-----------------------------------------+\n";
}
