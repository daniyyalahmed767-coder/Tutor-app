#include "TimeSlot.hpp"

int TimeSlot::nextSlotId = 1;

TimeSlot::TimeSlot() : slotId(0), date(""), time(""), isBooked(false) {}

TimeSlot::TimeSlot(const string& d, const string& t)
    : slotId(nextSlotId++), date(d), time(t), isBooked(false) {}

int    TimeSlot::getSlotId()   const { return slotId; }
string TimeSlot::getDate()     const { return date; }
string TimeSlot::getTime()     const { return time; }
bool   TimeSlot::getIsBooked() const { return isBooked; }

void TimeSlot::bookSlot() { isBooked = true; }
void TimeSlot::freeSlot() { isBooked = false; }

void TimeSlot::displaySlot() const {
    cout << "  Slot ID: " << slotId
         << " | Date: "   << date
         << " | Time: "   << time
         << " | Status: " << (isBooked ? "Booked" : "Available") << "\n";
}
