#pragma once
#include <string>
#include <iostream>
using namespace std;
class TimeSlot {
private:
    static int nextSlotId;  
    int    slotId;
    string date;
    string time;
    bool   isBooked;

public:
    TimeSlot();
    TimeSlot(const string& d, const string& t);

    int    getSlotId()   const;
    string getDate()     const;
    string getTime()     const;
    bool   getIsBooked() const;

    void bookSlot();
    void freeSlot();

    void displaySlot() const;
};
