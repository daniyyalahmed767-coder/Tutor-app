#include "Tutor.hpp"
#include "Exceptions.hpp"
#include <algorithm>
#include <iostream>
using namespace std;

int Tutor::nextTutorId = 1;

Tutor::Tutor() : User(), experienceYears(0), ratingSum(0.0f), ratingCount(0) {}

Tutor::Tutor(const string& n, const string& contact, int exp)
    : User(nextTutorId++, n, contact), experienceYears(exp),
      ratingSum(0.0f), ratingCount(0) {}

float Tutor::getRating() const {
    if (ratingCount == 0) return 0.0f;
    return ratingSum / (float)ratingCount;
}

int Tutor::getRatingCount()     const { return ratingCount; }
int Tutor::getExperienceYears() const { return experienceYears; }

void Tutor::addRating(float r) { ratingSum += r; ratingCount++; }

void Tutor::addSubject(const string& subject) { subjects.push_back(subject); }

void Tutor::addAvailability(const TimeSlot& slot) {
    int id = slot.getSlotId();
    bool dup = std::any_of(availableSlots.begin(), availableSlots.end(),
                           [id](const TimeSlot& s){ return s.getSlotId() == id; });
    if (dup) throw DuplicateSlotException(id);
    availableSlots.push_back(slot);
}

bool Tutor::teachesSubject(const string& subj) const {
    return std::any_of(subjects.begin(), subjects.end(),
                       [&subj](const string& s){ return s == subj; });
}

bool Tutor::isAvailable(int slotId) const {
    return std::any_of(availableSlots.begin(), availableSlots.end(),
                       [slotId](const TimeSlot& s){
                           return s.getSlotId() == slotId && !s.getIsBooked();
                       });
}

TimeSlot* Tutor::findSlot(int slotId) {
    for (int i = 0; i < (int)availableSlots.size(); i++)
        if (availableSlots[i].getSlotId() == slotId)
            return &availableSlots[i];
    return nullptr;
}

vector<TimeSlot>& Tutor::getAvailableSlots()   { return availableSlots; }
const vector<string>& Tutor::getSubjects() const { return subjects; }

void Tutor::viewProfile() {
    cout << "\n  ========== TUTOR PROFILE ==========\n";
    cout << "  ID          : " << getUserId()      << "\n";
    cout << "  Name        : " << getName()        << "\n";
    cout << "  Contact     : " << getContactInfo() << "\n";
    cout << "  Experience  : " << experienceYears  << " years\n";
    if (ratingCount == 0)
        cout << "  Rating      : No ratings yet\n";
    else
        cout << "  Rating      : " << getRating()
             << " / 5.0  (" << ratingCount << " review(s))\n";
    cout << "  Subjects    : ";
    for (int i = 0; i < (int)subjects.size(); i++) {
        cout << subjects[i];
        if (i < (int)subjects.size() - 1) cout << ", ";
    }
    cout << "\n  Available Slots:\n";
    if (availableSlots.empty())
        cout << "    No slots available.\n";
    else
        for (auto& s : availableSlots) s.displaySlot();
    cout << "  ====================================\n";
}
