#include "User.hpp"

User::User() : userId(0), name(""), contactInfo("") {}

User::User(int id, const string& n, const string& contact)
    : userId(id), name(n), contactInfo(contact) {}

int    User::getUserId()      const { return userId; }
string User::getName()        const { return name; }
string User::getContactInfo() const { return contactInfo; }

void User::setUserId(int id)           { userId = id; }
void User::setName(const string& n)    { name = n; }
void User::setContactInfo(const string& c) { contactInfo = c; }
