#pragma once
#include <string>
#include <iostream>
using namespace std;
class Session {
private:
    int    sessionId;
    string tutorName;
    string studentName;
    string subject;
    string slotInfo;    // display string e.g. "2025-06-10 10:00 AM"
    int    slotId;      
    string status;      
    bool   isRated;     
    float  studentRating;
    string studentReview;

public:
    Session();
    Session(int id, const string& tName, const string& sName,
            const string& subj, const string& slot, int sId);

    int    getSessionId()     const;
    string getTutorName()     const;
    string getStudentName()   const;
    string getSubject()       const;
    string getSlotInfo()      const;
    int    getSlotId()        const;
    string getStatus()        const;
    bool   getIsRated()       const;
    float  getStudentRating() const;
    string getStudentReview() const;

    void setStatus(const string& s);
    void setStudentName(const string& s);

    // Marks session Cancelled
    void cancelSession();

    // Marks session Completed and records rating + review
    // Platform validates before calling this
    void completeWithRating(float rating, const string& review);

    void displaySession() const;
};
