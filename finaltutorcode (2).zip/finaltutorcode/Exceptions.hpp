#pragma once
#include <string>
using namespace std;

//NOT inherit from std::exception to keep this self-contained.

class TutorNotFoundException {
    string message;
public:
    TutorNotFoundException(int id) {
        message = "Tutor not found with ID: " + to_string(id);
    }
    string what() const { return message; }
};

class StudentNotFoundException {
    string message;
public:
    StudentNotFoundException(const string& name) {
        message = "Student not found: " + name;
    }
    string what() const { return message; }
};

class SlotNotFoundException {
    string message;
public:
    SlotNotFoundException(int id) {
        message = "Slot ID not found: " + to_string(id);
    }
    string what() const { return message; }
};

class SessionNotFoundException {
    string message;
public:
    SessionNotFoundException(int id) {
        message = "Session ID not found: " + to_string(id);
    }
    string what() const { return message; }
};

class DuplicateSlotException {
    string message;
public:
    DuplicateSlotException(int id) {
        message = "Slot ID already exists: " + to_string(id);
    }
    string what() const { return message; }
};

class AlreadyCancelledException {
    string message;
public:
    AlreadyCancelledException(int id) {
        message = "Session " + to_string(id) + " is already cancelled.";
    }
    string what() const { return message; }
};

class RatingException {
    string message;
public:
    RatingException(const string& msg) : message(msg) {}
    string what() const { return message; }
};
