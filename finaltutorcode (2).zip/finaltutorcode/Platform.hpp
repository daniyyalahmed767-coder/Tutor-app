#pragma once
#include "Tutor.hpp"
#include "Student.hpp"
#include "Session.hpp"
#include "Waitlist.hpp"
#include "RecommendationEngine.hpp"
#include "Utilities.hpp"
#include <vector>
#include <string>
using namespace std;

// ─── Platform ─────────────────────────────────────────────────────────────────
// Central controller. Owns all tutors, students, sessions, and waitlists.
class Platform {
private:
    vector<Tutor>   tutors;
    vector<Student> students;
    vector<Session> sessions;
    RecommendationEngine recommender;
    int nextSessionId;

    vector<string>   waitlistKeys;
    vector<Waitlist> waitlists;

    int getWaitlistIndex(const string& key);

    Tutor*   findTutorById(int tutorId);
    Student* findStudentByName(const string& name);
    Session* findSessionById(int sessionId);

public:
    Platform();

    // ── Registration ──────────────────────────────────────────────────────────
    void addTutor(const Tutor& t);
    void addStudent(const Student& s);

    // ── Display ───────────────────────────────────────────────────────────────
    void showAllTutors();
    void showAllStudents();
    void showAllSessions();

    // ── Search ───────────────────────────────────────────────────────────────
    void viewTutorById(int tutorId);

    void searchTutors(const string& name, const string& subject);

    void recommendTutors(const string& subject);

    void bookSession(int tutorId, const string& studentName,
                     const string& subject, int slotId);

    void cancelSession(int sessionId, int studentId);

    void rateSession(int sessionId, const string& studentName,
                     float rating, const string& review);

    // ── Waitlist ──────────────────────────────────────────────────────────────
    void showWaitlist(int tutorId, int slotId);

    // ── Student history ───────────────────────────────────────────────────────
    void viewStudentHistory(const string& studentName);

    // ── Interactive menu (console) ────────────────────────────────────────────
    void menu();

    // Accessors for GUI
    vector<Tutor>&   getTutors()   { return tutors; }
    vector<Student>& getStudents() { return students; }
    vector<Session>& getSessions() { return sessions; }
};
