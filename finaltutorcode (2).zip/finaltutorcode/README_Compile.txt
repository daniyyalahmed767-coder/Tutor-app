Tutor Availability Platform - Compilation and Execution Guide

=========================================
1. REQUIREMENTS (What you need to run it)
=========================================
- A C++ compiler that supports C++17 (e.g., g++, clang++).
- Raylib Library: Required only if you want to compile and run the Graphical User Interface (GUI) version.
- CMake (Optional): A tool to automate the build process.

=========================================
2. HOW TO COMPILE AND RUN
=========================================

You can compile the project either directly using the compiler (g++) or by using CMake. Choose the method you prefer below.

-----------------------------------------
METHOD A: Direct Compilation (Using g++)
-----------------------------------------

1. Console Version (No Raylib required)
---------------------------------------
To compile:
g++ -std=c++17 TimeSlot.cpp Session.cpp Waitlist.cpp User.cpp Tutor.cpp Student.cpp RecommendationEngine.cpp Platform.cpp main.cpp -o platform_console

To run:
./platform_console
(On Windows: platform_console.exe)

2. GUI Version (Requires Raylib)
---------------------------------------
Note: Adjust the "-I/path/to/raylib/include" flag if your Raylib headers are installed in a different location.

To compile:
g++ -std=c++17 -I/path/to/raylib/include TimeSlot.cpp Session.cpp Waitlist.cpp User.cpp Tutor.cpp Student.cpp RecommendationEngine.cpp Platform.cpp gui_main.cpp -o platform_gui -lraylib -lm -ldl -lpthread -lGL -lX11

To run:
./platform_gui
(On Windows: platform_gui.exe)


-----------------------------------------
METHOD B: Compilation via CMake (Recommended)
-----------------------------------------

If you have CMake installed, it will automatically handle the linking for both the console and GUI versions.

1. Open your terminal in the project folder.
2. Create a build directory and enter it:
   mkdir build
   cd build
3. Generate the build files:
   cmake ..
4. Compile the project:
   make
5. Run the applications:
   ./platform_console    (To run the automated tests/console menu)
   ./platform_gui        (To run the graphical interface)
