#include "raylib.h"
#include "Platform.hpp"
#include "Exceptions.hpp"
#include <string>
#include <vector>
#include <sstream>
#include <cstring>
using namespace std;

// ─── Constants ────────────────────────────────────────────────────────────────
const int SCREEN_W = 1100;
const int SCREEN_H = 700;
const int PANEL_W  = 220;   // left sidebar width

// ─── Colour palette ───────────────────────────────────────────────────────────
static Color BG_DARK   = { 15,  17,  26, 255};
static Color BG_PANEL  = { 26,  30,  46, 255};
static Color BG_CARD   = { 35,  40,  60, 255};
static Color ACCENT    = { 99, 179, 237, 255};
static Color ACCENT2   = {155, 103, 255, 255};
static Color TXT_WHITE = {230, 235, 255, 255};
static Color TXT_GREY  = {140, 150, 180, 255};
static Color GREEN_C   = { 72, 199, 142, 255};
static Color RED_C     = {252,  92,  92, 255};
static Color ORANGE_C  = {255, 171,  76, 255};
static Color SIDEBAR_H = { 55,  60,  90, 255};

// ─── Screen enum ──────────────────────────────────────────────────────────────
enum Screen {
    SCR_DASHBOARD = 0,
    SCR_TUTORS,
    SCR_STUDENTS,
    SCR_SESSIONS,
    SCR_ADD_TUTOR,    // NEW
    SCR_ADD_STUDENT,  // NEW
    SCR_BOOK,
    SCR_CANCEL,
    SCR_SEARCH,
    SCR_RECOMMEND,
    SCR_WAITLIST,
    SCR_RATE,
    SCR_COUNT
};

const char* screenNames[SCR_COUNT] = {
    "Dashboard", "Tutors", "Students", "Sessions", 
    "Add Tutor", "Add Student", // NEW
    "Book", "Cancel", "Search", "Recommend", "Waitlist", "Rate Session"
};

// ─── Simple text-input box ────────────────────────────────────────────────────
struct TextBox {
    Rectangle rect;
    char      buf[64];
    bool      active;

    TextBox() : rect{0,0,0,0}, active(false) { buf[0] = '\0'; }
    TextBox(float x, float y, float w, float h)
        : rect{x,y,w,h}, active(false) { buf[0] = '\0'; }

    void update() {
        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON))
            active = CheckCollisionPointRec(GetMousePosition(), rect);
        if (active) {
            int key = GetCharPressed();
            while (key > 0) {
                int len = (int)strlen(buf);
                if (key >= 32 && len < 63) {
                    buf[len] = (char)key;
                    buf[len+1] = '\0';
                }
                key = GetCharPressed();
            }
            if (IsKeyPressed(KEY_BACKSPACE)) {
                int len = (int)strlen(buf);
                if (len > 0) buf[len-1] = '\0';
            }
        }
    }

    void draw(const char* label) const {
        Color border = active ? ACCENT : TXT_GREY;
        DrawRectangleRec(rect, BG_DARK);
        DrawRectangleLinesEx(rect, 1.5f, border);
        DrawText(label, (int)rect.x, (int)rect.y - 20, 14, TXT_GREY);
        DrawText(buf, (int)rect.x + 8, (int)rect.y + 8, 16, TXT_WHITE);
        if (active && ((int)(GetTime() * 2) % 2 == 0))
            DrawText("|", (int)rect.x + 8 + MeasureText(buf, 16),
                     (int)rect.y + 8, 16, ACCENT);
    }

    string text() const { return string(buf); }
    void   clear()       { buf[0] = '\0'; active = false; }
};

// ─── Dynamic Input Helper for Add Tutor ───────────────────────────────────────
struct DynamicInputs {
    vector<TextBox> subjectBoxes;
    vector<TextBox> slotBoxes;
    
    void clear() {
        subjectBoxes.clear();
        slotBoxes.clear();
    }
};

// ─── Button helper ────────────────────────────────────────────────────────────
bool GuiButton(Rectangle r, const char* label, Color col) {
    bool hovered = CheckCollisionPointRec(GetMousePosition(), r);
    Color bg = hovered ? ColorBrightness(col, 0.15f) : col;
    DrawRectangleRounded(r, 0.3f, 6, bg);
    int tw = MeasureText(label, 16);
    DrawText(label, (int)(r.x + r.width/2 - tw/2),
             (int)(r.y + r.height/2 - 8), 16, TXT_WHITE);
    return hovered && IsMouseButtonPressed(MOUSE_LEFT_BUTTON);
}

// ─── Card helper (rounded rect with title) ────────────────────────────────────
void DrawCard(float x, float y, float w, float h, const char* title) {
    DrawRectangleRounded({x, y, w, h}, 0.08f, 6, BG_CARD);
    DrawRectangleRounded({x, y, w, 36}, 0.08f, 6, BG_PANEL);
    DrawText(title, (int)x + 12, (int)y + 10, 16, ACCENT);
}

// ─── Sidebar ─────────────────────────────────────────────────────────────────
void DrawSidebar(Screen& current) {
    DrawRectangle(0, 0, PANEL_W, SCREEN_H, BG_PANEL);
    // Logo
    DrawText("TAP", 18, 18, 32, ACCENT);
    DrawText("Tutor Availability", 18, 52, 13, TXT_GREY);
    DrawText("Platform", 18, 68, 13, TXT_GREY);
    DrawLine(0, 92, PANEL_W, 92, SIDEBAR_H);

    for (int i = 0; i < SCR_COUNT; i++) {
        Rectangle btn = {0, (float)(110 + i * 46), (float)PANEL_W, 40}; // Adjusted height spacing to fit 12 items
        bool hov = CheckCollisionPointRec(GetMousePosition(), btn);
        bool sel = (current == (Screen)i);
        if (sel) DrawRectangleRec(btn, SIDEBAR_H);
        else if (hov) DrawRectangleRec(btn, {45, 50, 75, 255});
        if (sel) DrawRectangle(0, (int)btn.y, 4, 40, ACCENT);
        DrawText(screenNames[i], 20, (int)btn.y + 12, 16, sel ? TXT_WHITE : TXT_GREY);
        if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && hov)
            current = (Screen)i;
    }
    DrawText("OOP Final Project", 10, SCREEN_H - 24, 12, TXT_GREY);
}

// ─── Seed helper ──────────────────────────────────────────────────────────────
void seedPlatform(Platform& p) {
    // No manual IDs — auto-assigned by static counters
    Tutor t1("Alice",   "alice@uni.edu",   5);
    t1.addSubject("Math"); t1.addSubject("Physics");
    t1.addAvailability(TimeSlot("2025-06-10", "10:00 AM"));
    t1.addAvailability(TimeSlot("2025-06-11", "02:00 PM"));
    p.addTutor(t1);

    Tutor t2("Bob",     "bob@uni.edu",     2);
    t2.addSubject("Chemistry");
    t2.addAvailability(TimeSlot("2025-06-10", "10:00 AM"));
    p.addTutor(t2);

    Tutor t3("Charlie", "charlie@uni.edu", 8);
    t3.addSubject("Math");
    t3.addAvailability(TimeSlot("2025-06-10", "10:00 AM"));
    t3.addAvailability(TimeSlot("2025-06-12", "11:00 AM"));
    p.addTutor(t3);

    p.addStudent(Student("Zara",  "zara@s.com"));
    p.addStudent(Student("Ahmed", "ahmed@s.com"));
    p.addStudent(Student("Sara",  "sara@s.com"));
}

// ─── Scroll box renderer ──────────────────────────────────────────────────────
int scrollBox(float x, float y, float w, float h,
              const vector<string>& lines, int scroll) {
    DrawRectangleRounded({x, y, w, h}, 0.05f, 6, BG_DARK);
    BeginScissorMode((int)x, (int)y, (int)w, (int)h);
    int lineH = 22;
    for (int i = 0; i < (int)lines.size(); i++) {
        int py = (int)(y + 8 + i * lineH - scroll);
        if (py + lineH < (int)y || py > (int)(y + h)) continue;
        Color c = TXT_WHITE;
        if (lines[i].find("[PASS]") != string::npos) c = GREEN_C;
        else if (lines[i].find("[FAIL]") != string::npos) c = RED_C;
        else if (lines[i].find("[ERROR]") != string::npos) c = RED_C;
        else if (lines[i].find("Slot ID") != string::npos ||
                 lines[i].find("Status") != string::npos) c = ACCENT;
        DrawText(lines[i].c_str(), (int)x + 8, py, 15, c);
    }
    EndScissorMode();
    // Scroll
    int total = (int)(lines.size() * lineH);
    int wheel = (int)(GetMouseWheelMove() * 30);
    if (CheckCollisionPointRec(GetMousePosition(), {x, y, w, h}))
        scroll -= wheel;
    scroll = (scroll < 0) ? 0 : scroll;
    int maxScroll = total - (int)h + 16;
    if (scroll > maxScroll && maxScroll > 0) scroll = maxScroll;
    // Scrollbar
    if (total > (int)h) {
        float frac = (float)scroll / (float)maxScroll;
        float barH = h / total * h;
        float barY = y + frac * (h - barH);
        DrawRectangle((int)(x + w - 8), (int)barY, 6, (int)barH, ACCENT2);
    }
    return scroll;
}

// Capture cout into a vector<string>
struct CoutCapture {
    streambuf* old;
    ostringstream oss;
    CoutCapture() { old = cout.rdbuf(oss.rdbuf()); }
    ~CoutCapture() { cout.rdbuf(old); }
    vector<string> lines() {
        vector<string> out;
        istringstream ss(oss.str());
        string l;
        while (getline(ss, l)) out.push_back(l);
        return out;
    }
};

// ─── MAIN ─────────────────────────────────────────────────────────────────────
int main() {
    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_WINDOW_RESIZABLE);
    InitWindow(SCREEN_W, SCREEN_H, "Tutor Availability Platform");
    SetTargetFPS(60);

    Platform platform;
    seedPlatform(platform);

    Screen   currentScreen = SCR_DASHBOARD;
    string   statusMsg     = "";
    Color    statusCol     = GREEN_C;
    vector<string> outputLines;
    int      scroll        = 0;

    // ── Book screen inputs ──────────────────────────────────────────────────
    TextBox tbTutorId (PANEL_W + 30, 160, 200, 36);
    TextBox tbStudName(PANEL_W + 30, 240, 260, 36);
    TextBox tbSubject (PANEL_W + 30, 320, 260, 36);
    TextBox tbSlotId  (PANEL_W + 30, 400, 200, 36);

    // ── Cancel screen input ─────────────────────────────────────────────────
    TextBox tbCancelId(PANEL_W + 30, 180, 200, 36);
    TextBox tbCancelStudId(PANEL_W + 30, 260, 200, 36);

    // ── Recommend screen inputs (subject only) ──────────────────────────────
    TextBox tbRecSubj (PANEL_W + 30, 160, 300, 36);

    // ── Search screen inputs ─────────────────────────────────────────────────
    TextBox tbSrchName (PANEL_W + 30, 160, 280, 36);
    TextBox tbSrchSubj (PANEL_W + 30, 240, 280, 36);

    // ── Waitlist screen inputs ──────────────────────────────────────────────
    TextBox tbWlTutor (PANEL_W + 30, 160, 200, 36);
    TextBox tbWlSlot  (PANEL_W + 30, 240, 200, 36);

    // -- Rate screen inputs ──────────────────────────────────────────────────
    TextBox tbRateSessId  (PANEL_W + 30, 160, 200, 36);
    TextBox tbRateStudName(PANEL_W + 30, 240, 260, 36);
    TextBox tbRateScore   (PANEL_W + 30, 320, 160, 36);
    TextBox tbRateReview  (PANEL_W + 30, 400, 400, 36);

    // ── Add Tutor / Student inputs ──────────────────────────────────────────
    DynamicInputs tutorInputData;
    TextBox tbAddTutorName(PANEL_W + 30, 160, 300, 36);
    TextBox tbAddTutorCont(PANEL_W + 30, 240, 300, 36);
    TextBox tbAddTutorExp (PANEL_W + 30, 320, 100, 36);
    
    TextBox tbAddStudName(PANEL_W + 30, 160, 300, 36);
    TextBox tbAddStudCont(PANEL_W + 30, 240, 300, 36);


    while (!WindowShouldClose()) {
        // Update active text box for current screen
        if (currentScreen == SCR_BOOK) {
            tbTutorId.update(); tbStudName.update();
            tbSubject.update(); tbSlotId.update();
        } else if (currentScreen == SCR_CANCEL) {
            tbCancelId.update();
            tbCancelStudId.update();
        } else if (currentScreen == SCR_SEARCH) {
            tbSrchName.update(); tbSrchSubj.update();
        } else if (currentScreen == SCR_RECOMMEND) {
            tbRecSubj.update();
        } else if (currentScreen == SCR_WAITLIST) {
            tbWlTutor.update(); tbWlSlot.update();
        } else if (currentScreen == SCR_RATE) {
            tbRateSessId.update(); tbRateStudName.update();
            tbRateScore.update();  tbRateReview.update();
        } else if (currentScreen == SCR_ADD_TUTOR) {
            tbAddTutorName.update(); 
            tbAddTutorCont.update(); 
            tbAddTutorExp.update();
            for (auto& b : tutorInputData.subjectBoxes) b.update();
            for (auto& b : tutorInputData.slotBoxes) b.update();
        } else if (currentScreen == SCR_ADD_STUDENT) {
            tbAddStudName.update(); 
            tbAddStudCont.update();
        }

        BeginDrawing();
        ClearBackground(BG_DARK);

        DrawSidebar(currentScreen);

        float cx = PANEL_W + 20;
        float cy = 20;
        float cw = SCREEN_W - PANEL_W - 40;

        // ── DASHBOARD ────────────────────────────────────────────────────────
        if (currentScreen == SCR_DASHBOARD) {
            DrawText("Dashboard", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 50;

            auto& tutors   = platform.getTutors();
            auto& students = platform.getStudents();
            auto& sessions = platform.getSessions();

            // Stat cards row
            auto statCard = [&](float x, float y, const char* lbl,
                                const char* val, Color col) {
                DrawRectangleRounded({x, y, 180, 90}, 0.15f, 8, BG_CARD);
                DrawRectangleRounded({x, y, 180, 4}, 0.5f, 4, col);
                DrawText(lbl, (int)x + 14, (int)y + 20, 14, TXT_GREY);
                DrawText(val, (int)x + 14, (int)y + 44, 30, col);
            };

            char buf[16];
            snprintf(buf, sizeof(buf), "%d", (int)tutors.size());
            statCard(cx,       cy, "Tutors",   buf, ACCENT);
            snprintf(buf, sizeof(buf), "%d", (int)students.size());
            statCard(cx+200,   cy, "Students", buf, ACCENT2);
            int sched = 0, completed = 0, cancelled = 0;
            for (auto& s : sessions) {
                if (s.getStatus() == "Scheduled") sched++;
                else if (s.getStatus() == "Completed") completed++;
                else cancelled++;
            }
            snprintf(buf, sizeof(buf), "%d", sched);
            statCard(cx+400,   cy, "Scheduled", buf, GREEN_C);
            snprintf(buf, sizeof(buf), "%d", completed);
            statCard(cx+600,   cy, "Completed", buf, ACCENT);
            snprintf(buf, sizeof(buf), "%d", cancelled);
            statCard(cx+800,   cy, "Cancelled", buf, RED_C);
            cy += 120;

            // Recent sessions table
            DrawCard(cx, cy, cw, 240, "Recent Sessions");
            cy += 44;
            DrawText("ID",      (int)cx+12,  (int)cy, 14, TXT_GREY);
            DrawText("Tutor",   (int)cx+60,  (int)cy, 14, TXT_GREY);
            DrawText("Student", (int)cx+230, (int)cy, 14, TXT_GREY);
            DrawText("Subject", (int)cx+400, (int)cy, 14, TXT_GREY);
            DrawText("Status",  (int)cx+560, (int)cy, 14, TXT_GREY);
            cy += 22;
            DrawLine((int)cx+8, (int)cy, (int)(cx+cw-8), (int)cy, SIDEBAR_H);
            cy += 8;
            int rowH = 28, shown = 0;
            for (int i = (int)sessions.size()-1; i >= 0 && shown < 6; i--, shown++) {
                auto& s = sessions[i];
                Color sc = (s.getStatus() == "Scheduled") ? GREEN_C : RED_C;
                DrawText(to_string(s.getSessionId()).c_str(), (int)cx+12, (int)cy, 14, TXT_WHITE);
                DrawText(s.getTutorName().c_str(),   (int)cx+60,  (int)cy, 14, TXT_WHITE);
                DrawText(s.getStudentName().c_str(), (int)cx+230, (int)cy, 14, TXT_WHITE);
                DrawText(s.getSubject().c_str(),     (int)cx+400, (int)cy, 14, TXT_WHITE);
                DrawText(s.getStatus().c_str(),      (int)cx+560, (int)cy, 14, sc);
                cy += rowH;
            }
            if (sessions.empty()) DrawText("No sessions yet.", (int)cx+12, (int)cy, 14, TXT_GREY);

            // Tips
            cy += 16;
            DrawCard(cx, cy, cw, 80, "Quick Tips");
            DrawText("• Book: Tutor ID + Student Name + Subject + Slot ID",
                     (int)cx+12, (int)cy+42, 14, TXT_GREY);
            DrawText("• Priority Waitlist: students ranked by Reliability Score (unique feature)",
                     (int)cx+12, (int)cy+60, 14, TXT_GREY);
        }

        // ── TUTORS ────────────────────────────────────────────────────────────
        else if (currentScreen == SCR_TUTORS) {
            DrawText("All Tutors", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 50;
            auto& tutors = platform.getTutors();
            if (tutors.empty()) {
                DrawText("No tutors registered.", (int)cx, (int)cy, 18, TXT_GREY);
            }
            float cardH = 160;
            for (int i = 0; i < (int)tutors.size(); i++) {
                auto& t = tutors[i];
                float cardY = cy + i * (cardH + 12);
                if (cardY > SCREEN_H) break;
                DrawRectangleRounded({cx, cardY, cw, cardH}, 0.06f, 6, BG_CARD);
                DrawRectangle((int)cx, (int)cardY, 5, (int)cardH, ACCENT);
                // Avatar circle
                DrawCircle((int)(cx+50), (int)(cardY+50), 32, ACCENT2);
                DrawText(t.getName().substr(0,1).c_str(),
                         (int)(cx+40), (int)(cardY+36), 28, TXT_WHITE);
                // Info
                DrawText(t.getName().c_str(),    (int)(cx+100), (int)(cardY+16), 20, TXT_WHITE);
                DrawText(("ID: " + to_string(t.getUserId())).c_str(),
                         (int)(cx+100), (int)(cardY+42), 14, TXT_GREY);
                DrawText((to_string(t.getExperienceYears())+" yrs exp").c_str(),
                         (int)(cx+100), (int)(cardY+62), 14, TXT_GREY);
                DrawText(t.getContactInfo().c_str(),
                         (int)(cx+100), (int)(cardY+82), 14, TXT_GREY);
                // Rating bar
                DrawText("Rating:", (int)(cx+100), (int)(cardY+106), 13, TXT_GREY);
                DrawRectangleRounded({cx+160, cardY+106, 160, 12}, 0.5f, 4, BG_PANEL);
                DrawRectangleRounded({cx+160, cardY+106, t.getRating()/5.0f*160, 12},
                                     0.5f, 4, ACCENT);
                char ratingStr[32];
                if (t.getRatingCount() == 0) snprintf(ratingStr, sizeof(ratingStr), "No ratings yet");
                else snprintf(ratingStr, sizeof(ratingStr), "%.2f / 5.0 (%d reviews)", t.getRating(), t.getRatingCount());
                DrawText(ratingStr,
                         (int)(cx+330), (int)(cardY+104), 13, TXT_WHITE);
                // Subjects
                const auto& subj = t.getSubjects();
                string subjStr = "Subjects: ";
                for (int j = 0; j < (int)subj.size(); j++) {
                    subjStr += subj[j];
                    if (j < (int)subj.size()-1) subjStr += ", ";
                }
                DrawText(subjStr.c_str(), (int)(cx+100), (int)(cardY+128), 13, ACCENT);
                // Slot count
                int avail = 0;
                for (auto& sl : t.getAvailableSlots())
                    if (!sl.getIsBooked()) avail++;
                string slotStr = to_string(avail) + " slot(s) free";
                Color slotCol = avail > 0 ? GREEN_C : RED_C;
                DrawText(slotStr.c_str(), (int)(cx+cw-130), (int)(cardY+20), 14, slotCol);
            }
        }

        // ── STUDENTS ─────────────────────────────────────────────────────────
        else if (currentScreen == SCR_STUDENTS) {
            DrawText("All Students", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 50;
            auto& students = platform.getStudents();
            if (students.empty()) DrawText("No students.", (int)cx, (int)cy, 18, TXT_GREY);
            float cardH = 120;
            for (int i = 0; i < (int)students.size(); i++) {
                auto& s = students[i];
                float cardY = cy + i * (cardH + 10);
                if (cardY > SCREEN_H) break;
                DrawRectangleRounded({cx, cardY, cw, cardH}, 0.06f, 6, BG_CARD);
                DrawCircle((int)(cx+50), (int)(cardY+46), 28, ACCENT);
                DrawText(s.getName().substr(0,1).c_str(),
                         (int)(cx+40), (int)(cardY+32), 24, TXT_WHITE);
                DrawText(s.getName().c_str(),   (int)(cx+94), (int)(cardY+14), 20, TXT_WHITE);
                DrawText(("ID: "+to_string(s.getUserId())).c_str(),
                         (int)(cx+94), (int)(cardY+40), 13, TXT_GREY);
                DrawText(s.getContactInfo().c_str(),
                         (int)(cx+94), (int)(cardY+58), 13, TXT_GREY);
                // Reliability bar
                float rel = s.reliabilityScore();
                DrawText("Reliability:", (int)(cx+94), (int)(cardY+80), 13, TXT_GREY);
                DrawRectangleRounded({cx+180, cardY+80, 140, 10}, 0.5f, 4, BG_PANEL);
                Color rc = rel > 0.7f ? GREEN_C : (rel > 0.4f ? ORANGE_C : RED_C);
                DrawRectangleRounded({cx+180, cardY+80, rel*140, 10}, 0.5f, 4, rc);
                char rbuf[16]; snprintf(rbuf, sizeof(rbuf), "%.2f", rel);
                DrawText(rbuf, (int)(cx+330), (int)(cardY+78), 13, rc);
                DrawText(("Booked: "+to_string(s.getTotalBooked())+
                          "  Cancelled: "+to_string(s.getCancelledCount())).c_str(),
                         (int)(cx+cw-260), (int)(cardY+14), 13, TXT_GREY);
            }
        }

        // ── SESSIONS ─────────────────────────────────────────────────────────
        else if (currentScreen == SCR_SESSIONS) {
            DrawText("All Sessions", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 50;
            auto& sessions = platform.getSessions();
            // Table header
            DrawText("ID",      (int)(cx+8),   (int)cy, 14, TXT_GREY);
            DrawText("Tutor",   (int)(cx+60),  (int)cy, 14, TXT_GREY);
            DrawText("Student", (int)(cx+240),  (int)cy, 14, TXT_GREY);
            DrawText("Subject", (int)(cx+400), (int)cy, 14, TXT_GREY);
            DrawText("Slot",    (int)(cx+530), (int)cy, 14, TXT_GREY);
            DrawText("Status",  (int)(cx+700), (int)cy, 14, TXT_GREY);
            cy += 22;
            DrawLine((int)cx, (int)cy, (int)(cx+cw), (int)cy, SIDEBAR_H);
            cy += 6;
            if (sessions.empty())
                DrawText("No sessions recorded.", (int)cx, (int)cy+10, 16, TXT_GREY);
            for (auto& s : sessions) {
                if (cy > SCREEN_H - 30) break;
                Color sc = (s.getStatus() == "Scheduled") ? GREEN_C : RED_C;
                DrawText(to_string(s.getSessionId()).c_str(),(int)(cx+8),(int)cy,14,TXT_WHITE);
                DrawText(s.getTutorName().c_str(),   (int)(cx+60),  (int)cy, 14, TXT_WHITE);
                DrawText(s.getStudentName().c_str(), (int)(cx+240),  (int)cy, 14, TXT_WHITE);
                DrawText(s.getSubject().c_str(),     (int)(cx+400), (int)cy, 14, TXT_WHITE);
                DrawText(s.getSlotInfo().c_str(),    (int)(cx+530), (int)cy, 13, TXT_GREY);
                DrawRectangleRounded({cx+700, cy-2, 90, 22}, 0.4f, 4, ColorAlpha(sc, 0.2f));
                DrawText(s.getStatus().c_str(),      (int)(cx+708), (int)cy, 13, sc);
                cy += 30;
            }
        }

        // ── ADD TUTOR ─────────────────────────────────────────────────────────
        else if (currentScreen == SCR_ADD_TUTOR) {
            DrawText("Register New Tutor", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 45;
            
            // Draw static fields
            tbAddTutorName.draw("Full Name");
            tbAddTutorCont.draw("Contact (Email)");
            tbAddTutorExp.draw("Years of Experience");

            float dynamicY = 380;

            // --- SUBJECTS SECTION ---
            DrawText("Subjects:", (int)cx, (int)dynamicY, 16, ACCENT);
            if (GuiButton({cx + 100, dynamicY - 5, 30, 25}, "+", GREEN_C)) {
                tutorInputData.subjectBoxes.push_back(TextBox(cx, dynamicY + 25 + (tutorInputData.subjectBoxes.size() * 45), 200, 30));
            }
            for (size_t i = 0; i < tutorInputData.subjectBoxes.size(); i++) {
                tutorInputData.subjectBoxes[i].draw(i == 0 ? "Subject Name" : "");
            }
            
            // --- SLOTS SECTION ---
            float slotX = cx + 250;
            DrawText("Availability (YYYY-MM-DD,HH:MM AM):", (int)slotX, (int)dynamicY, 16, ACCENT);
            if (GuiButton({slotX + 310, dynamicY - 5, 30, 25}, "+", GREEN_C)) {
                tutorInputData.slotBoxes.push_back(TextBox(slotX, dynamicY + 25 + (tutorInputData.slotBoxes.size() * 45), 250, 30));
            }
            for (size_t i = 0; i < tutorInputData.slotBoxes.size(); i++) {
                tutorInputData.slotBoxes[i].draw(i == 0 ? "Date & Time" : "");
            }

            // --- SUBMIT LOGIC ---
            if (GuiButton({cx, 630, 180, 40}, "Register Tutor", ACCENT)) {
                Tutor newTutor(tbAddTutorName.text(), tbAddTutorCont.text(), atoi(tbAddTutorExp.buf));
                
                // Add all subjects from dynamic boxes
                for (auto& b : tutorInputData.subjectBoxes) {
                    if (strlen(b.buf) > 0) newTutor.addSubject(b.text());
                }

                // Add all slots from dynamic boxes
                for (auto& b : tutorInputData.slotBoxes) {
                    string s = b.text();
                    size_t comma = s.find(',');
                    if (comma != string::npos) {
                        newTutor.addAvailability(TimeSlot(s.substr(0, comma), s.substr(comma + 1)));
                    }
                }

                platform.addTutor(newTutor);
                
                // Clear everything
                tbAddTutorName.clear(); tbAddTutorCont.clear(); tbAddTutorExp.clear();
                tutorInputData.clear();
                outputLines = {"[PASS] Tutor registered with dynamic subjects and slots."};
                scroll = 0;
            }

            if (!outputLines.empty()) {
                scroll = scrollBox(cx + 200, 630, cw - 200, 40, outputLines, scroll);
            }
        }

        // ── ADD STUDENT ──────────────────────────────────────────────────────
        else if (currentScreen == SCR_ADD_STUDENT) {
            DrawText("Register New Student", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 50;
            DrawCard(cx, cy, 400, 220, "Student Information");
            
            tbAddStudName.draw("Full Name");
            tbAddStudCont.draw("Contact (Email)");

            if (GuiButton({cx, 380, 200, 40}, "Register Student", ACCENT2)) {
                string name = tbAddStudName.text();
                string cont = tbAddStudCont.text();
                
                if(!name.empty() && !cont.empty()) {
                    platform.addStudent(Student(name, cont));
                    tbAddStudName.clear(); tbAddStudCont.clear();
                    outputLines = {"[PASS] Student registered successfully."};
                    scroll = 0;
                } else {
                    outputLines = {"[ERROR] Name and Contact are required."};
                    scroll = 0;
                }
            }
            if (!outputLines.empty()) {
                scroll = scrollBox(cx, 440, cw, 100, outputLines, scroll);
            }
        }

        // ── BOOK SESSION ─────────────────────────────────────────────────────
        else if (currentScreen == SCR_BOOK) {
            DrawText("Book Session", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 46;
            DrawCard(cx, cy, 380, 310, "Session Details");

            tbTutorId.draw("Tutor ID");
            tbStudName.draw("Student Name");
            tbSubject.draw("Subject");
            tbSlotId.draw("Slot ID");

            if (GuiButton({cx, 470, 180, 40}, "Book Session", GREEN_C)) {
                int tid = atoi(tbTutorId.buf);
                int sid = atoi(tbSlotId.buf);
                string sName   = tbStudName.text();
                string subject = tbSubject.text();
                CoutCapture cap;
                platform.bookSession(tid, sName, subject, sid);
                outputLines = cap.lines();
                scroll = 0;
                tbTutorId.clear(); tbStudName.clear();
                tbSubject.clear(); tbSlotId.clear();
            }

            if (!outputLines.empty()) {
                DrawText("Result:", (int)(cx+20), 520, 14, TXT_GREY);
                scroll = scrollBox(cx, 538, cw, SCREEN_H-560, outputLines, scroll);
            }
        }

        // ── CANCEL SESSION ────────────────────────────────────────────────────
        else if (currentScreen == SCR_CANCEL) {
            DrawText("Cancel Session", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 50;
            DrawCard(cx, cy, 340, 200, "Cancel by Session ID"); 
            
            tbCancelId.draw("Session ID");
            tbCancelStudId.draw("Student ID");

            if (GuiButton({cx, 420, 180, 40}, "Cancel Session", RED_C)) {
                int sid = atoi(tbCancelId.buf);
                int stid = atoi(tbCancelStudId.buf); 
                CoutCapture cap;
                platform.cancelSession(sid, stid);   
                outputLines = cap.lines();
                scroll = 0;
                tbCancelId.clear();
                tbCancelStudId.clear(); 
            }

            if (!outputLines.empty()) {
                DrawText("Result:", (int)(cx+20), 480, 14, TXT_GREY); 
                scroll = scrollBox(cx, 498, cw, SCREEN_H-520, outputLines, scroll); 
            }
        }

        // ── SEARCH TUTORS ─────────────────────────────────────────────────────
        else if (currentScreen == SCR_SEARCH) {
            DrawText("Search Tutors", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 14;
            DrawText("Search by name, subject, or both. Leave a field blank to skip it.",
                     (int)cx, (int)(cy+22), 14, TXT_GREY);
            cy += 60;
            DrawCard(cx, cy, 380, 160, "Search Filters");
            tbSrchName.draw("Tutor Name (leave blank to skip)");
            tbSrchSubj.draw("Subject   (leave blank to skip)");

            if (GuiButton({cx, 380, 180, 42}, "Search", ACCENT)) {
                CoutCapture cap;
                platform.searchTutors(tbSrchName.text(), tbSrchSubj.text());
                outputLines = cap.lines();
                scroll = 0;
            }
            if (GuiButton({cx+200, 380, 100, 42}, "Clear", TXT_GREY)) {
                tbSrchName.clear(); tbSrchSubj.clear();
                outputLines.clear();
            }
            if (!outputLines.empty()) {
                DrawText("Results:", (int)(cx+20), 438, 14, TXT_GREY);
                scroll = scrollBox(cx, 456, cw, SCREEN_H-478, outputLines, scroll);
            }
        }


        // ── RECOMMEND ─────────────────────────────────────────────────────────
        else if (currentScreen == SCR_RECOMMEND) {
            DrawText("Recommend Tutors", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 14;
            DrawText("Ranked by student rating. All tutors who teach the subject shown,",
                     (int)cx, (int)(cy+22), 14, TXT_GREY);
            DrawText("even if their slots are full (you can join the waitlist).",
                     (int)cx, (int)(cy+40), 14, TXT_GREY);
            cy += 70;
            DrawCard(cx, cy, 360, 100, "Search by Subject");
            tbRecSubj.draw("Subject (e.g. Math)");

            if (GuiButton({cx, 330, 220, 42}, "Get Recommendations", ACCENT2)) {
                CoutCapture cap;
                platform.recommendTutors(tbRecSubj.text());
                outputLines = cap.lines();
                scroll = 0;
            }
            if (!outputLines.empty()) {
                DrawText("Results:", (int)(cx+20), 390, 14, TXT_GREY);
                scroll = scrollBox(cx, 408, cw, SCREEN_H-430, outputLines, scroll);
            }
        }

        // ── WAITLIST ──────────────────────────────────────────────────────────
        else if (currentScreen == SCR_WAITLIST) {
            DrawText("Priority Waitlist", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 14;
            DrawText("Students ranked by Reliability Score (highest = served first)",
                     (int)cx, (int)(cy+22), 14, TXT_GREY);
            cy += 60;
            DrawCard(cx, cy, 360, 160, "Query Waitlist");

            tbWlTutor.draw("Tutor ID");
            tbWlSlot.draw("Slot ID");

            if (GuiButton({cx, 380, 180, 40}, "Show Waitlist", ACCENT)) {
                CoutCapture cap;
                platform.showWaitlist(atoi(tbWlTutor.buf), atoi(tbWlSlot.buf));
                outputLines = cap.lines();
                scroll = 0;
            }
            if (!outputLines.empty()) {
                DrawText("Waitlist:", (int)(cx+20), 436, 14, TXT_GREY);
                scroll = scrollBox(cx, 454, cw, SCREEN_H-476, outputLines, scroll);
            }
        }

        // -- RATE SESSION -------------------------------------------------
        else if (currentScreen == SCR_RATE) {
            DrawText("Rate a Session", (int)cx, (int)cy, 28, TXT_WHITE);
            cy += 14;
            DrawText("Only the attending student can rate. Rating is 0.0 - 5.0.",
                     (int)cx, (int)(cy+22), 14, TXT_GREY);
            cy += 60;
            DrawCard(cx, cy, 460, 280, "Submit Rating & Review");

            tbRateSessId.draw("Session ID");
            tbRateStudName.draw("Your Name (must match booking)");
            tbRateScore.draw("Rating (0.0 - 5.0)");
            tbRateReview.draw("Review (optional)");

            if (GuiButton({cx, 500, 220, 42}, "Submit Rating", GREEN_C)) {
                int sid      = atoi(tbRateSessId.buf);
                float rating = (float)atof(tbRateScore.buf);
                CoutCapture cap;
                platform.rateSession(sid, tbRateStudName.text(),
                                     rating, tbRateReview.text());
                outputLines = cap.lines();
                scroll = 0;
                tbRateSessId.clear(); tbRateStudName.clear();
                tbRateScore.clear();  tbRateReview.clear();
            }
            if (!outputLines.empty()) {
                DrawText("Result:", (int)(cx+20), 558, 14, TXT_GREY);
                scroll = scrollBox(cx, 576, cw, SCREEN_H-598, outputLines, scroll);
            }
        }


        // ── Status bar ────────────────────────────────────────────────────────
        if (!statusMsg.empty()) {
            DrawRectangle(PANEL_W, SCREEN_H-36, SCREEN_W-PANEL_W, 36, BG_CARD);
            DrawText(statusMsg.c_str(), PANEL_W+12, SCREEN_H-24, 14, statusCol);
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}