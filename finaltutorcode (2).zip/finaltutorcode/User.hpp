#pragma once
#include <string>
#include <iostream>
using namespace std;

class User {
private:
    int    userId;
    string name;
    string contactInfo;

public:
    User();
    User(int id, const string& n, const string& contact);
    virtual ~User() {}

    int    getUserId()     const;
    string getName()       const;
    string getContactInfo() const;

    void setUserId(int id);
    void setName(const string& n);
    void setContactInfo(const string& c);

    virtual void viewProfile() = 0; 
};
