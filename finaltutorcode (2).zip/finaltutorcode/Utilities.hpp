#pragma once
#include <vector>
#include <string>
#include <iostream>
using namespace std;

template<typename T, typename Predicate>
T* linearSearch(vector<T>& vec, Predicate pred) {
    for (int i = 0; i < (int)vec.size(); i++) {
        if (pred(vec[i]))
            return &vec[i];
    }
    return nullptr;
}

// Returns a vector of pointers to all elements matching the predicate.
template<typename T, typename Predicate>
vector<T*> filterVec(vector<T>& vec, Predicate pred) {
    vector<T*> result;
    for (int i = 0; i < (int)vec.size(); i++) {
        if (pred(vec[i]))
            result.push_back(&vec[i]);
    }
    return result;
}

// Calls displayFn on every element in the vector.
template<typename T>
void displayAll(vector<T>& vec, void(*displayFn)(T&)) {
    for (int i = 0; i < (int)vec.size(); i++) {
        displayFn(vec[i]);
    }
}

// Sorts two parallel vectors (keys and values) in descending order of key.
template<typename V>
void bubbleSortDesc(vector<float>& keys, vector<V>& values) {
    int n = (int)keys.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (keys[j] > keys[i]) {
                float tmpK = keys[i]; keys[i] = keys[j]; keys[j] = tmpK;
                V    tmpV = values[i]; values[i] = values[j]; values[j] = tmpV;
            }
        }
    }
}

//trimStr (helper for input cleaning)
inline string trimStr(const string& s) {
    int start = 0, end = (int)s.size() - 1;
    while (start <= end && s[start] == ' ') start++;
    while (end >= start && s[end] == ' ')   end--;
    return s.substr(start, end - start + 1);
}
